# use a for loop to iterate over elements in a list and perform some operations


# use while loop to find factorial of a number


# iterate through a string and print each character
myString = "Hello"
print("Iterate over a string: ", myString)
for item in myString:
    print(item)
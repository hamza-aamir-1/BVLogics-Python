first = int(input("Enter first number: "))
second = int(input("Enter second number: "))

# implement basic arithmetic operations (+, -, *, /) on two numbers input by user
print("Addition: ", first + second)
print("Subtraction: ", first - second)
print("Multiplication: ", first * second)
print("Division: ", first / second)

# calculate the ramiander of the division
print("Remainder of Division: ", first % second)

# increment and decrement a number
print("Incremented Numbers: ", first + 1, " -- ", second + 1)
print("Decremented Numbers: ", first - 1, " -- ", second - 1)
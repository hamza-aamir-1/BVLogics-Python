# reverse a given string
myString = "Hello World!"
print("Reverse a string: ", myString, " -- ", myString[::-1])

# count occurances of a particular character in a string
print("Count specific character: ", "o -- ", myString.count("o"))

# convert a string to uppercase and lowercase
print("String to uppercase: ", myString.upper())
print("String to lowercase: ", myString.lower())
#membership in 

x = ["Ali", "Hamza"]
print("Ali" in x)

# not in 
x = ["Ali", "Hamza"]
print("Haroon" not in x)



#Identity is

x = ["Ali", "Taimoor"]
y = ["Ali", "Taimoor"]
z = x
print(x is z)
print(x is y)
print(x == y)


# Task: Write a Python program that takes a number as input and prints its absolute value
num = int(input("Enter a number: "))
print("Absolute value of ", num, " is ", abs(num))

# Task 2: Write a Python program that takes two numbers as input and prints the difference between the larger and smaller number
num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))
print("Difference between ", num1, " and ", num2, " is ", num1 - num2)
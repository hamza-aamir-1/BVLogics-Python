# Task: Write a Python program that takes a number as input and prints its square
num = int(input("Enter a number: "))
print("Square of ", num, " is ", num * num)
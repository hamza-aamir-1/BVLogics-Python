# Task 1: Write a Python program that takes a string as input and prints its length
# Task 2: Write a Python program that takes a string as input and prints it in uppercase
name = input("Enter your full name: ")
print("Your name's length is ", len(name))
print("Your name in uppercase is ", name.upper())

# Task 3: Write a Python program that takes two strings as input and concatenates them
city = input("Enter your city: ")
country = input("Enter your country: ")
print("Your address is ", city + ", " + country)
